

![](Pasted%20image%2020220804095101.png)

