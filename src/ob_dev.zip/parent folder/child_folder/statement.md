

![](Pasted%20image%2020220804095052.png)

