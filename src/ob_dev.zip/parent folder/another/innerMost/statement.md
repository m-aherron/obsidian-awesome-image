

![](Pasted%20image%2020220804095022.png)


![](Pasted%20image%2020220804095044.png)

